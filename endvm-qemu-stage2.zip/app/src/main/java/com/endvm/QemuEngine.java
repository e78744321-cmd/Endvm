package com.endvm;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public final class QemuEngine {
    private QemuEngine() {}

    public static boolean isBundled(Context context) {
        File binary = new File(context.getApplicationInfo().nativeLibraryDir,
                "libqemu-system-x86_64.so");
        return binary.isFile();
    }

    public static String version(Context context) throws Exception {
        return run(context, "libqemu-system-x86_64.so", "--version");
    }

    public static String createDisk(Context context) throws Exception {
        File disk = new File(context.getFilesDir(), "android-x86_64.qcow2");
        if (disk.exists() && disk.length() > 0) {
            return "Диск уже существует:\n" + disk.getAbsolutePath();
        }
        String output = run(context, "libqemu-img.so",
                "create", "-f", "qcow2", disk.getAbsolutePath(), "8G");
        return output + "\nФайл диска: " + disk.getAbsolutePath();
    }

    private static String run(Context context, String executableName, String... args)
            throws Exception {
        File executable = new File(context.getApplicationInfo().nativeLibraryDir,
                executableName);
        if (!executable.isFile()) {
            throw new IOException("Не найден " + executableName
                    + ". Сначала собери APK через workflow Build endvm with QEMU.");
        }

        prepareAssets(context);

        File qemuRoot = new File(context.getFilesDir(), "qemu");
        File libDir = new File(qemuRoot, "lib");
        File dataDir = new File(qemuRoot, "share/qemu");

        ProcessBuilder builder = new ProcessBuilder();
        java.util.List<String> command = new java.util.ArrayList<>();
        command.add(executable.getAbsolutePath());
        for (String arg : args) command.add(arg);
        builder.command(command);
        builder.directory(context.getFilesDir());
        builder.redirectErrorStream(true);

        Map<String, String> env = builder.environment();
        env.put("HOME", context.getFilesDir().getAbsolutePath());
        env.put("TMPDIR", context.getCacheDir().getAbsolutePath());
        env.put("LD_LIBRARY_PATH", libDir.getAbsolutePath()
                + ":" + context.getApplicationInfo().nativeLibraryDir);
        env.put("QEMU_DATADIR", dataDir.getAbsolutePath());

        Process process = builder.start();
        boolean finished = process.waitFor(45, TimeUnit.SECONDS);
        if (!finished) {
            process.destroyForcibly();
            throw new IOException("QEMU не ответил за 45 секунд.");
        }

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (output.length() < 6000) output.append(line).append('\n');
            }
        }

        if (process.exitValue() != 0) {
            throw new IOException("Код " + process.exitValue() + ": " + output);
        }
        return output.length() == 0 ? "Команда выполнена успешно." : output.toString().trim();
    }

    private static void prepareAssets(Context context) throws IOException {
        File root = new File(context.getFilesDir(), "qemu");
        copyAssetTree(context.getAssets(), "qemu/lib", new File(root, "lib"));
        copyAssetTree(context.getAssets(), "qemu/share/qemu", new File(root, "share/qemu"));
    }

    private static void copyAssetTree(AssetManager assets, String assetPath, File destination)
            throws IOException {
        String[] children = assets.list(assetPath);
        if (children == null || children.length == 0) {
            File parent = destination.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("Не удалось создать " + parent);
            }
            try (InputStream in = assets.open(assetPath);
                 FileOutputStream out = new FileOutputStream(destination)) {
                byte[] buffer = new byte[32 * 1024];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
            return;
        }

        if (!destination.exists() && !destination.mkdirs()) {
            throw new IOException("Не удалось создать " + destination);
        }
        for (String child : children) {
            copyAssetTree(assets, assetPath + "/" + child,
                    new File(destination, child));
        }
    }
}
