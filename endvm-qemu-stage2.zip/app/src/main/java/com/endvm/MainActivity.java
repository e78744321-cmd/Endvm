package com.endvm;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int PICK_ISO = 41;
    private TextView status;
    private TextView isoLabel;
    private Uri isoUri;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 24);
        page.setBackgroundColor(0xFF10121A);

        TextView title = new TextView(this);
        title.setText("endvm");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, 1);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("QEMU Virtual Machine · Android ARM64");
        subtitle.setTextColor(0xFFB9BED0);
        subtitle.setPadding(0, 4, 0, 22);
        page.addView(subtitle);

        addButton(page, "Выбрать Android x86 ISO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_ISO);
        });

        isoLabel = new TextView(this);
        isoLabel.setText("ISO: не выбран");
        isoLabel.setTextColor(0xFFE3E6F2);
        isoLabel.setPadding(0, 12, 0, 16);
        page.addView(isoLabel);

        TextView config = new TextView(this);
        config.setText("Профиль первой VM\nГость: Android-x86_64\nRAM: 1024 MB\nДиск: 8 GB (QCOW2)\nCPU: 2 виртуальных ядра\nУскорение: TCG (программное)");
        config.setTextColor(0xFFE3E6F2);
        config.setTextSize(16);
        config.setPadding(0, 8, 0, 18);
        page.addView(config);

        addButton(page, "Проверить движок QEMU", v -> checkQemu());
        addButton(page, "Создать виртуальный диск 8 ГБ", v -> createDisk());

        status = new TextView(this);
        status.setText(QemuEngine.isBundled(this)
                ? "Движок найден. Нажми «Проверить движок QEMU»."
                : "Движок ещё не встроен. Запусти workflow «Build endvm with QEMU» на GitHub.");
        status.setTextColor(0xFFFFD18A);
        status.setPadding(0, 18, 0, 12);
        page.addView(status);

        TextView note = new TextView(this);
        note.setText("Важно: этот этап проверяет запуск QEMU и создание диска. Экран виртуальной машины и управление Android-гостем пока не подключены.");
        note.setTextColor(0xFF9EA5BA);
        note.setTextSize(13);
        page.addView(note);

        setContentView(page);
    }

    private void addButton(LinearLayout root, String text, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(click);
        root.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }

    private void checkQemu() {
        status.setText("Проверяю QEMU…");
        new Thread(() -> {
            String result;
            try {
                result = QemuEngine.version(this);
            } catch (Exception e) {
                result = "Ошибка запуска QEMU: " + e.getMessage();
            }
            final String message = result;
            runOnUiThread(() -> status.setText(message));
        }).start();
    }

    private void createDisk() {
        status.setText("Создаю виртуальный диск…");
        new Thread(() -> {
            String result;
            try {
                result = QemuEngine.createDisk(this);
            } catch (Exception e) {
                result = "Ошибка создания диска: " + e.getMessage();
            }
            final String message = result;
            runOnUiThread(() -> status.setText(message));
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ISO && resultCode == RESULT_OK && data != null) {
            isoUri = data.getData();
            if (isoUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            isoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (SecurityException ignored) {
                    // Some document providers do not support persistable grants.
                }
                isoLabel.setText("ISO выбран: " + isoUri.getLastPathSegment());
                status.setText("ISO выбран. Сначала проверь QEMU и создай диск.");
            }
        }
    }
}
