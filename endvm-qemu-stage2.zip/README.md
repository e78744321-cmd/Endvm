# endvm — QEMU integration stage

This project targets an Android ARM64 phone and an x86_64 guest using QEMU TCG software emulation.

## What this stage adds

- A GitHub Actions workflow that builds `qemu-system-x86_64` and `qemu-img` for Android ARM64.
- The workflow collects the Termux-prefix shared libraries needed by those binaries and bundles them into the APK.
- The app can run `qemu-system-x86_64 --version` as an on-device engine check.
- The app can create an 8 GiB QCOW2 virtual disk using `qemu-img`.

## Build

1. Put this project in the root of the `Endvm` GitHub repository.
2. Make sure the workflow file is at `.github/workflows/build-endvm-full.yml`.
3. Open **Actions → Build endvm with QEMU → Run workflow**.
4. Download the `endvm-qemu-debug-apk` artifact and install it on the ARM64 Android phone.

The workflow also uploads `endvm-qemu-runtime-arm64` for inspection.

## Current limitations — important

This is an engine-integration and validation stage, not a finished virtual-machine app.
The app currently checks the QEMU executable and can create a virtual disk. It does **not**
yet boot the selected ISO into a visible guest screen. A VNC/display and input bridge,
ISO copying, VM lifecycle controls, and real-device runtime validation are still required.

QEMU is built for the ARM64 Android host while emulating an x86_64 guest with TCG. This is
software emulation and can be slow. The first VM profile is 1 GiB RAM, 2 vCPUs, and an 8 GiB
QCOW2 disk.

## Package note

The Termux build's `-I` option downloads dependencies into the build prefix instead of
building each dependency package locally. The workflow therefore copies the shared libraries
from that installed prefix into the app bundle rather than assuming the QEMU `.deb` alone is
self-contained.
