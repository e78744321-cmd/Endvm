package com.endvm;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, isoLabel;
    private Uri isoUri;
    private static final int PICK_ISO = 41;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 24);
        page.setBackgroundColor(0xFF10121A);

        TextView title = new TextView(this);
        title.setText("endvm");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, 1);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("QEMU Virtual Machine Manager · ARM64");
        subtitle.setTextColor(0xFFB9BED0);
        subtitle.setPadding(0, 4, 0, 24);
        page.addView(subtitle);

        addButton(page, "Выбрать Android x86 ISO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_ISO);
        });

        isoLabel = new TextView(this);
        isoLabel.setText("ISO: не выбран");
        isoLabel.setTextColor(0xFFE3E6F2);
        isoLabel.setPadding(0, 12, 0, 16);
        page.addView(isoLabel);

        TextView config = new TextView(this);
        config.setText("Профиль первой VM\nГость: Android-x86_64\nRAM: 1024 MB\nДиск: 8 GB (QCOW2)\nCPU: 2 виртуальных ядра");
        config.setTextColor(0xFFE3E6F2);
        config.setTextSize(16);
        config.setPadding(0, 12, 0, 22);
        page.addView(config);

        addButton(page, "Подготовить команду QEMU", v -> prepareVm());
        status = new TextView(this);
        status.setText("Состояние: QEMU engine ещё не встроен.");
        status.setTextColor(0xFFFFD18A);
        status.setPadding(0, 20, 0, 12);
        page.addView(status);

        TextView note = new TextView(this);
        note.setText("Это исходный каркас приложения. Для реального запуска нужен собранный под Android ARM64 бинарник qemu-system-x86_64 и его библиотеки. Обычный Linux-бинарник QEMU здесь не запустится.");
        note.setTextColor(0xFF9EA5BA);
        note.setTextSize(13);
        page.addView(note);

        setContentView(page);
    }

    private void addButton(LinearLayout root, String text, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(click);
        root.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }

    private void prepareVm() {
        if (isoUri == null) {
            status.setText("Сначала выбери ISO Android-x86.");
            return;
        }
        status.setText("ISO выбран. Запуск пока недоступен: в APK ещё нет Android-сборки QEMU.");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ISO && resultCode == RESULT_OK && data != null) {
            isoUri = data.getData();
            getContentResolver().takePersistableUriPermission(isoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            isoLabel.setText("ISO: " + isoUri.getLastPathSegment());
            status.setText("ISO выбран. Можно подготовить интеграцию движка.");
        }
    }
}
