# endvm

Android ARM64 project scaffold for a QEMU-based virtual machine manager.

## Current status
This initial project builds an Android APK and provides the VM manager UI and ISO picker.
**It does not yet contain QEMU.** A real x86_64 guest requires an Android/ARM64 build of
`qemu-system-x86_64` plus all required Android-compatible shared libraries (or a carefully
built static dependency set). A normal Linux QEMU executable cannot be copied into an APK
and expected to run on Android.

## First VM profile
- Guest: Android-x86_64
- RAM: 1024 MiB
- Virtual disk target: 8 GiB QCOW2
- Host ABI: arm64-v8a
- Emulator mode: TCG software emulation (not KVM)

## Build
Push this repository to GitHub, then open **Actions → Build endvm APK → Run workflow**.
Download the `endvm-debug-apk` artifact.

## Next engineering stage
Build/package QEMU and its dependencies for Android arm64, bundle the executable and
libraries in the app, implement private-storage disk creation, and launch QEMU with
a virtual display/input bridge. This is not implemented in this starter ZIP.
