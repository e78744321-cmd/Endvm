package com.endvm;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int PICK_ISO = 1001;
    private TextView isoStatus;
    private Uri selectedIso;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("endvm");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Android ARM64 • QEMU virtual machine");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFFB8C7D9);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 12, 0, 28);
        page.addView(subtitle, matchWrap());

        Button choose = new Button(this);
        choose.setText("Выбрать ISO");
        page.addView(choose, matchWrap());
        choose.setOnClickListener(v -> chooseIso());

        isoStatus = new TextView(this);
        isoStatus.setText("ISO не выбран");
        isoStatus.setTextColor(0xFFFFFFFF);
        isoStatus.setPadding(0, 20, 0, 20);
        page.addView(isoStatus, matchWrap());

        TextView status = new TextView(this);
        status.setText("Статус: подготовка проекта\n\nЭтот APK пока содержит интерфейс выбора ISO. Исполняемый QEMU для Android ещё не встроен, поэтому запуск виртуальной машины пока недоступен.");
        status.setTextColor(0xFFFFD27D);
        status.setTextSize(14);
        status.setPadding(0, 12, 0, 12);
        page.addView(status, matchWrap());

        Button start = new Button(this);
        start.setText("Запустить виртуальную машину");
        start.setEnabled(false);
        page.addView(start, matchWrap());

        setContentView(page);
    }

    private void chooseIso() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_ISO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ISO && resultCode == RESULT_OK && data != null) {
            selectedIso = data.getData();
            if (selectedIso != null) {
                getContentResolver().takePersistableUriPermission(
                    selectedIso, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                isoStatus.setText("Выбран ISO:\n" + selectedIso.getLastPathSegment());
            }
        }
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
