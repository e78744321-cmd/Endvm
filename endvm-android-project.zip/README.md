# endvm Android project

This is the initial Android ARM64 app shell and GitHub Actions APK build.

## Important status
The current APK includes the app interface and ISO document picker only.
QEMU is **not yet embedded**, and the Start VM button is disabled. The Termux
`.deb` packages produced by the separate QEMU workflow are not Android APK
native libraries and cannot simply be copied into the APK. A later integration
step must package QEMU and its runtime dependencies for Android and connect
the emulator process to the app UI.

## Build
Push this project to the `main` branch or run the `Build endvm APK` workflow
manually from GitHub Actions. Download the `endvm-debug-apk` artifact.
